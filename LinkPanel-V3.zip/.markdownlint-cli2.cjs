module.exports = {
	config: {
		// MD010/no-hard-tabs
		MD010: false,
		// MD013/line-length
		MD013: false,
		// MD024/no-duplicate-heading/no-duplicate-header
		MD024: false,
		// MD033/no-inline-html
		MD033: false,
	},
};
