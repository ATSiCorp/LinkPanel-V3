.js and .php files placed in this directory will automatically be included in scripts loading init.js.

subfolders will be ignored (recursive file loading is not supported. you're free to create sub-folders, but they will not be invoked automatically.)

These custom files will persist across LinkPanelCP upgrades.

This directory is not meant for LinkPanelCP development, but meant for people wanting to customize their own LinkPanelCP control panel.

Warning: modifications to this README.txt may be lost during LinkPanelCP upgrades.
