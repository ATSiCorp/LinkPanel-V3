module.exports = {
	env: {
		browser: false,
		node: true,
	},
	rules: {
		'no-console': 'off',
	},
};
