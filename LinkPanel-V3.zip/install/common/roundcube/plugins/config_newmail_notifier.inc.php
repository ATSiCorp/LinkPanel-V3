<?php

// Enables basic notification
$config["newmail_notifier_basic"] = true;

// Enables sound notification
$config["newmail_notifier_sound"] = false;

// Enables desktop notification
$config["newmail_notifier_desktop"] = false;

// Desktop notification close timeout in seconds
$config["newmail_notifier_desktop_timeout"] = 5;

?>
