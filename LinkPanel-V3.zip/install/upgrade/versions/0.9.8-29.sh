#!/bin/bash

# LinkPanel Control Panel upgrade script for target version 0.9.8-28

#######################################################################################
#######                      Place additional commands below.                   #######
#######################################################################################

# Add amd64 to repositories to prevent notifications - https://goo.gl/hmsSV7
if ! grep -q 'arch=amd64' /etc/apt/sources.list.d/nginx.list; then
	sed -i s/"deb "/"deb [arch=amd64] "/g /etc/apt/sources.list.d/nginx.list
fi
if ! grep -q 'arch=amd64' /etc/apt/sources.list.d/mariadb.list; then
	sed -i s/"deb "/"deb [arch=amd64] "/g /etc/apt/sources.list.d/mariadb.list
fi

# Fix named rule for AppArmor - https://goo.gl/SPqHdq
if [ "$DNS_SYSTEM" = 'bind9' ] && [ ! -f /etc/apparmor.d/local/usr.sbin.named ]; then
	echo "/home/** rwm," >> /etc/apparmor.d/local/usr.sbin.named 2> /dev/null
fi

# Remove obsolete ports.conf if exists.
if [ -f /usr/local/linkpanel/data/firewall/ports.conf ]; then
	rm -f /usr/local/linkpanel/data/firewall/ports.conf
fi

# Move clamav to proper location - https://goo.gl/zNuM11
if [ ! -d /usr/local/linkpanel/web/edit/server/clamav-daemon ]; then
	mv /usr/local/linkpanel/web/edit/server/clamd /usr/local/web/edit/server/clamav-daemon
fi
