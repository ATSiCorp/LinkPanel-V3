<template>
	<div class="InstallPage">
		<slot></slot>
	</div>
</template>

<style scoped>
.InstallPage {
	line-height: 1.5;
}
</style>
