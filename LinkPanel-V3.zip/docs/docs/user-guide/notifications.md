# Notifications

To view your notifications, click the <i class="fas fa-lg fa-fw fa-bell"><span class="visually-hidden">notification</span></i> icon in the top right.

You can delete a notification by clicking the <i class="fas fa-lg fa-fw fa-xmark"><span class="visually-hidden">delete</span></i> icon on the top right.
