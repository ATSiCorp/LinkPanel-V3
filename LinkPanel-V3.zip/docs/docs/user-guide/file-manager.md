# File Manager

To access the file manager, click the **<i class="fas fa-fw fa-folder-open"></i> Files** button in the top left.

The file manager LinkPanel uses is called FileGator. You can find more information about it on [their website](https://filegator.io/).
