# Contributing to LinkPanel’s translations

If you are a non-English speaker and would like to improve the quality of the translations used in LinkPanel’s web interface, please go to [LinkPanel Translate](https://translate.linkpanelcp.com/) to review the translations database. For more information, please read [How to contribute with Translations](https://forum.linkpanelcp.com/t/how-to-contribute-with-translations/1664) on our forum.
