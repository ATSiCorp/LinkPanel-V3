---
aside: false
lastUpdated: false
---

# Donate to the project

By donating to LinkPanel, you help maintain server costs, development time, and more!

Here are our official donation platforms:

- [PayPal](https://www.paypal.com/donate/?cmd=_s-xclick&hosted_button_id=ST87LQH2CHGLA)
- Crypto
  - Bitcoin: bc1q48jt5wg5jaj8g9zy7c3j03cv57j2m2u5anlutu
  - Ethereum: 0xfF3Dd2c889bd0Ff73d8085B84A314FC7c88e5D51
  - Binance: bnb1l4ywvw5ejfmsgjdcx8jn5lxj7zsun8ktfu7rh8
  - Smart Chain: 0xfF3Dd2c889bd0Ff73d8085B84A314FC7c88e5D51
